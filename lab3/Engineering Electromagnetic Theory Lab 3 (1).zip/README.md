# oreilly-latex-template
O'Reilly Latex Template by Joan Queralt translated to english from https://tex.stackexchange.com/questions/107862/oreilly-template
