clear;
clc;

%Parameters
rho = 1e-9;
%ViewLimits
range_size_x = 4;
range_size_y = 3;
range_sampling_rate = 100;
range_vec_x = linspace(-range_size_x / 2, range_size_x /...
 2, range_size_x * range_sampling_rate);
range_vec_y = linspace(-range_size_y / 2, range_size_y /...
 2, range_size_y * range_sampling_rate);
[mesh_x, mesh_y] = meshgrid(range_vec_x, range_vec_y);

%Use formula to calculate V
V = Constants.k .* rho .* ...
log((1 - mesh_x + sqrt((1 - mesh_x) .* (1 -mesh_x) + mesh_y .* mesh_y)) ...
./ (-1 - mesh_x + sqrt((-1 - mesh_x) .* (-1 -mesh_x) + mesh_y .* mesh_y)));

%draw the condition of V 
figure(1);
grid on, axis equal;
mesh(mesh_x, mesh_y, V);
title(["Integration Method - Charge Potential Distribution","(Gan Yuhao, 12211629)"]);
axis([-range_size_x / 2, range_size_x / 2, -range_size_y / 2, range_size_y / 2, 0, 100]);
xlabel('X(m)'),ylabel('Y(m)'),zlabel('V(v)');

%draw COntours
V_eq_min = 0;
V_eq_max = 60;
V_eq_sampling_num = 10;
V_eq = linspace(V_eq_min, V_eq_max, V_eq_sampling_num);

figure(2);
hold on,grid on, axis equal;
contour(mesh_x, mesh_y, V, V_eq);
title(["Integration Method - Contours", "(Gan Yuhao, 12211629)"]);
xlabel("x (m)"), ylabel("y (m)");

%draw Streamlines 
[E_x, E_y] = gradient(-V);
%Set place where streamlines appear
angles = linspace(-pi / 2, pi / 2, 3);
Ori_Point = 0.05;
appear_x = [-1 - Ori_Point .* cos(angles), linspace(-1, 1, 10), linspace(-1, 1, 10), 1 + Ori_Point .* cos(angles)];
appear_y = [Ori_Point * sin(angles), Ori_Point * ones(1, 10),-Ori_Point * ones(1, 10), -Ori_Point * sin(angles)];

figure(3);
hold on, grid on, axis equal;
contourf(mesh_x, mesh_y, V,V_eq);
fig_3 = streamline(mesh_x, mesh_y, E_x, E_y, appear_x, appear_y);
set(fig_3,"lineWidth", 1.2, "color", [0.2, 0.7, 0.7]);
xlabel("x (m)"), ylabel("y (m)");
title(["Integration Method - Equipotential Lines and Streamlines", "(Gan Yuhao,12211629)"]);



















