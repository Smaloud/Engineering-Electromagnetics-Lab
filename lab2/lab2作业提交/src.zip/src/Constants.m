classdef Constants
    properties(Constant)
        k = 9e9
    end
end